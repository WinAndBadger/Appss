package com.example.apps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class FrameActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        TextView txv2 = (TextView) findViewById(R.id.textView2);
        txv2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(FrameActivity.this, SixthActivity.class));
            }
        });
    }
}
